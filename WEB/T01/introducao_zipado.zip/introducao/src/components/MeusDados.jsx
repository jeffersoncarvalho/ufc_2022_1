import React, { Component } from "react";

/*const MeusDados = () =>
 <div>
     <h3>Nome: Jefferson de Carvalho</h3>
     <h3>Curso: Sistemas de Informação</h3>
     <h3>Universidade: UFC - Quixadá</h3>
 </div>
*/

class MeusDados extends Component {

    render() {
        return (
            <div>
                <h3>Nome: Jefferson de Carvalho</h3>
                <h3>Curso: Sistemas de Informação</h3>
                <h3>Universidade: UFC - Quixadá</h3>
            </div>
        )
    }
}

export default MeusDados