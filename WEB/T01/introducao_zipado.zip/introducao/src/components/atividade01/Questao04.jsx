import React from "react";
import QuestaoO2 from "./Questao02";

class Questao04 extends React.Component {
    render() {
        return <QuestaoO2
                    nome = "Beltrano de Souza"
                    curso = "Telecomunicações"
                    cidade = "São Paulo" 
                />
    }
}

export default Questao04