import React from "react";

import QuestaoO1 from "./Questao01";

const Questao03 = () => 
    <QuestaoO1
        nome = "Sicrano da Silva"
        curso = "Arquitetura"
        cidade = "Natal" 
    />
export default Questao03